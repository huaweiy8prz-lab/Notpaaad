package com.example.notebook.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
 @Query("""SELECT * FROM notes WHERE deleted=0 AND archived=0
 AND (title LIKE '%'||:q||'%' OR content LIKE '%'||:q||'%' OR tags LIKE '%'||:q||'%' OR category LIKE '%'||:q||'%')
 ORDER BY pinned DESC, updatedAt DESC""")
 fun active(q:String):Flow<List<Note>>

 @Query("SELECT * FROM notes WHERE deleted=1 ORDER BY updatedAt DESC")
 fun trash():Flow<List<Note>>

 @Query("SELECT * FROM notes WHERE archived=1 AND deleted=0 ORDER BY updatedAt DESC")
 fun archived():Flow<List<Note>>

 @Query("SELECT * FROM notes ORDER BY id")
 suspend fun all():List<Note>

 @Insert suspend fun insert(n:Note):Long
 @Update suspend fun update(n:Note)

 @Query("UPDATE notes SET pinned=NOT pinned,updatedAt=:t WHERE id=:id")
 suspend fun pin(id:Long,t:Long=System.currentTimeMillis())

 @Query("UPDATE notes SET favorite=NOT favorite,updatedAt=:t WHERE id=:id")
 suspend fun favorite(id:Long,t:Long=System.currentTimeMillis())

 @Query("UPDATE notes SET archived=1,updatedAt=:t WHERE id=:id")
 suspend fun archive(id:Long,t:Long=System.currentTimeMillis())

 @Query("UPDATE notes SET archived=0,updatedAt=:t WHERE id=:id")
 suspend fun unarchive(id:Long,t:Long=System.currentTimeMillis())

 @Query("UPDATE notes SET deleted=1,archived=0,updatedAt=:t WHERE id=:id")
 suspend fun trash(id:Long,t:Long=System.currentTimeMillis())

 @Query("UPDATE notes SET deleted=0,updatedAt=:t WHERE id=:id")
 suspend fun restore(id:Long,t:Long=System.currentTimeMillis())

 @Query("DELETE FROM notes WHERE id=:id")
 suspend fun permanent(id:Long)

 @Query("DELETE FROM notes WHERE deleted=1")
 suspend fun emptyTrash()
}
