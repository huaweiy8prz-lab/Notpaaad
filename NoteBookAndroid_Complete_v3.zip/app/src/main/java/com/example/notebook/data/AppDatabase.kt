package com.example.notebook.data
import android.content.Context
import androidx.room.*

@Database(entities=[Note::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
 abstract fun dao():NoteDao
 companion object{
  @Volatile private var INSTANCE:AppDatabase?=null
  fun get(c:Context)=INSTANCE?:synchronized(this){
   INSTANCE?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"notebook.db")
    .fallbackToDestructiveMigration().build().also{INSTANCE=it}
  }
 }
}
