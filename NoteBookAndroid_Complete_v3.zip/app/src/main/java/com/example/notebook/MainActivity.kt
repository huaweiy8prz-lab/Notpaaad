package com.example.notebook

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.notebook.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class NoteVM(app:Application):AndroidViewModel(app){
 private val dao=AppDatabase.get(app).dao()
 private val query=MutableStateFlow("")
 private val favOnly=MutableStateFlow(false)

 val notes=combine(query,favOnly){q,f->q to f}.flatMapLatest{(q,f)->
  dao.active(q).map{list->if(f)list.filter{it.favorite}else list}
 }.stateIn(viewModelScope,SharingStarted.Eagerly,emptyList())

 val trash=dao.trash().stateIn(viewModelScope,SharingStarted.Eagerly,emptyList())
 val archived=dao.archived().stateIn(viewModelScope,SharingStarted.Eagerly,emptyList())

 fun search(s:String){query.value=s}
 fun favorites(){favOnly.value=!favOnly.value}

 fun save(old:Note?,title:String,content:String,category:String,tags:String,check:String,color:Int)=viewModelScope.launch{
  val now=System.currentTimeMillis()
  if(old==null)dao.insert(Note(title=title,content=content,category=category,tags=tags,checklist=check,color=color))
  else dao.update(old.copy(title=title,content=content,category=category,tags=tags,checklist=check,color=color,updatedAt=now))
 }
 fun pin(id:Long)=viewModelScope.launch{dao.pin(id)}
 fun favorite(id:Long)=viewModelScope.launch{dao.favorite(id)}
 fun archive(id:Long)=viewModelScope.launch{dao.archive(id)}
 fun unarchive(id:Long)=viewModelScope.launch{dao.unarchive(id)}
 fun trash(id:Long)=viewModelScope.launch{dao.trash(id)}
 fun restore(id:Long)=viewModelScope.launch{dao.restore(id)}
 fun permanent(id:Long)=viewModelScope.launch{dao.permanent(id)}
 fun emptyTrash()=viewModelScope.launch{dao.emptyTrash()}

 fun backup():String{
  val a=JSONArray()
  runBlocking{dao.all().forEach{n->
   a.put(JSONObject().apply{
    put("title",n.title);put("content",n.content);put("category",n.category);put("tags",n.tags)
    put("checklist",n.checklist);put("color",n.color);put("createdAt",n.createdAt);put("updatedAt",n.updatedAt)
    put("pinned",n.pinned);put("favorite",n.favorite);put("archived",n.archived);put("deleted",n.deleted)
   })
  }}
  return a.toString(2)
 }
 fun restoreBackup(text:String)=viewModelScope.launch{
  val a=JSONArray(text)
  for(i in 0 until a.length()){
   val o=a.getJSONObject(i)
   dao.insert(Note(
    title=o.optString("title"),content=o.optString("content"),category=o.optString("category","عمومی"),
    tags=o.optString("tags"),checklist=o.optString("checklist"),color=o.optInt("color"),
    createdAt=o.optLong("createdAt",System.currentTimeMillis()),updatedAt=o.optLong("updatedAt",System.currentTimeMillis()),
    pinned=o.optBoolean("pinned"),favorite=o.optBoolean("favorite"),archived=o.optBoolean("archived"),deleted=o.optBoolean("deleted")
   ))
  }
 }
}

class VMFactory(private val app:Application):ViewModelProvider.Factory{
 override fun <T:ViewModel>create(c:Class<T>):T{
  @Suppress("UNCHECKED_CAST") return NoteVM(app) as T
 }
}

class MainActivity:ComponentActivity(){
 private var pendingImport:String?=null
 private val createFile=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
  if(uri!=null){
   val text=getSharedPreferences("backup",0).getString("data","")?:""
   contentResolver.openOutputStream(uri)?.use{it.write(text.toByteArray())}
  }
 }
 private val openFile=registerForActivityResult(ActivityResultContracts.OpenDocument(arrayOf("application/json"))){uri->
  if(uri!=null){
   pendingImport=contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
  }
 }
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  setContent{
   val vm:NoteVM=viewModel(factory=VMFactory(application))
   MainScreen(vm,{s->getSharedPreferences("backup",0).edit().putString("data",s).apply();createFile.launch("notebook-backup.json")},{openFile.launch(arrayOf("application/json"))},pendingImport,{pendingImport=null})
  }
 }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm:NoteVM,export:()->Unit,import:()->Unit,pending:String?,clear:()->Unit){
 var tab by remember{mutableIntStateOf(0)}
 var edit by remember{mutableStateOf(false)}
 var selected by remember{mutableStateOf<Note?>(null)}
 var dark by remember{mutableStateOf(false)}
 val notes by vm.notes.collectAsState()
 val trash by vm.trash.collectAsState()
 val archived by vm.archived.collectAsState()

 LaunchedEffect(pending){if(pending!=null){vm.restoreBackup(pending);clear()}}

 MaterialTheme(colorScheme=if(dark)darkColorScheme() else lightColorScheme()){
  if(edit){
   Editor(selected,{edit=false}){t,c,cat,tags,check,color->vm.save(selected,t,c,cat,tags,check,color);edit=false}
  }else{
   Scaffold(
    topBar={TopAppBar(
     title={Text(when(tab){1->"بایگانی";2->"سطل زباله";3->"تنظیمات";else->"یادداشت‌ها"},fontWeight=FontWeight.Bold)},
     actions={
      if(tab==0)IconButton({vm.favorites()}){Icon(Icons.Default.Star,null)}
      if(tab==3)IconButton({dark=!dark}){Icon(if(dark)Icons.Default.LightMode else Icons.Default.DarkMode,null)}
     }
    )},
    bottomBar={NavigationBar{
     NavigationBarItem(tab==0,{tab=0},icon={Icon(Icons.Default.Notes,null)},label={Text("یادداشت‌ها")})
     NavigationBarItem(tab==1,{tab=1},icon={Icon(Icons.Default.Archive,null)},label={Text("بایگانی")})
     NavigationBarItem(tab==2,{tab=2},icon={Icon(Icons.Default.Delete,null)},label={Text("سطل")})
     NavigationBarItem(tab==3,{tab=3},icon={Icon(Icons.Default.Settings,null)},label={Text("تنظیمات")})
    }},
    floatingActionButton={if(tab==0)FloatingActionButton({selected=null;edit=true}){Icon(Icons.Default.Add,null)}}
   ){p->
    when(tab){
     0->Home(notes,vm,{selected=it;edit=true})
     1->Archive(archived,vm)
     2->Trash(trash,vm)
     3->Settings(dark,{dark=!dark},export,import)
    }
   }
  }
 }
}

@Composable
fun Home(ns:List<Note>,vm:NoteVM,onEdit:(Note)->Unit){
 var q by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp)){
  OutlinedTextField(q,{q=it;vm.search(it)},Modifier.fillMaxWidth(),placeholder={Text("جست‌وجوی عنوان، متن، دسته و برچسب")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
  Spacer(Modifier.height(12.dp))
  LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=90.dp)){
   items(ns,key={it.id}){n->NoteCard(n,{onEdit(n)},{vm.pin(n.id)},{vm.favorite(n.id)},{vm.archive(n.id)},{vm.trash(n.id)})}
  }
 }
}

@Composable
fun NoteCard(n:Note,edit:()->Unit,pin:()->Unit,fav:()->Unit,archive:()->Unit,trash:()->Unit){
 Card(Modifier.fillMaxWidth().clickable{edit()},shape=RoundedCornerShape(18.dp)){
  Column(Modifier.padding(14.dp)){
   Row(verticalAlignment=Alignment.CenterVertically){
    Text(n.title.ifBlank{"بدون عنوان"},Modifier.weight(1f),fontWeight=FontWeight.Bold)
    IconButton(pin){Icon(Icons.Default.PushPin,null)}
    IconButton(fav){Icon(if(n.favorite)Icons.Default.Star else Icons.Default.StarBorder,null)}
    IconButton(trash){Icon(Icons.Default.Delete,null)}
   }
   Text(n.category,style=MaterialTheme.typography.labelSmall)
   if(n.content.isNotBlank()){Spacer(Modifier.height(6.dp));Text(n.content,maxLines=4)}
   if(n.checklist.isNotBlank()){Spacer(Modifier.height(6.dp));Text("☑ چک‌لیست دارد",style=MaterialTheme.typography.labelSmall)}
   if(n.tags.isNotBlank()){Spacer(Modifier.height(4.dp));Text("برچسب: ${n.tags}",style=MaterialTheme.typography.labelSmall)}
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
    Text(date(n.updatedAt),style=MaterialTheme.typography.labelSmall,Modifier.weight(1f))
    TextButton(archive){Text("بایگانی")}
   }
  }
 }
}

@Composable
fun Archive(ns:List<Note>,vm:NoteVM){
 LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  items(ns){n->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
   Text(n.title.ifBlank{"بدون عنوان"},Modifier.weight(1f));IconButton({vm.unarchive(n.id)}){Icon(Icons.Default.Unarchive,null)}
  }}}
 }
}

@Composable
fun Trash(ns:List<Note>,vm:NoteVM){
 Column(Modifier.fillMaxSize().padding(16.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
   Text("سطل زباله",Modifier.weight(1f));TextButton({vm.emptyTrash()}){Text("خالی کردن")}
  }
  LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(ns){n->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
    Text(n.title.ifBlank{"بدون عنوان"},Modifier.weight(1f))
    IconButton({vm.restore(n.id)}){Icon(Icons.Default.Restore,null)}
    IconButton({vm.permanent(n.id)}){Icon(Icons.Default.DeleteForever,null)}
   }}}
  }
 }
}

@Composable
fun Settings(dark:Boolean,toggle:()->Unit,export:()->Unit,import:()->Unit){
 Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
   Text("حالت تاریک",Modifier.weight(1f));Switch(dark,{toggle()})
  }}
  Button(export,Modifier.fillMaxWidth()){Icon(Icons.Default.Backup,null);Spacer(Modifier.width(8.dp));Text("پشتیبان‌گیری")}
  OutlinedButton(import,Modifier.fillMaxWidth()){Icon(Icons.Default.Restore,null);Spacer(Modifier.width(8.dp));Text("بازیابی پشتیبان")}
  Text("دفترچه یادداشت • نسخه 3.0",style=MaterialTheme.typography.bodySmall)
 }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Editor(n:Note?,back:()->Unit,save:(String,String,String,String,String,Int)->Unit){
 var title by remember{mutableStateOf(n?.title?:"")}
 var content by remember{mutableStateOf(n?.content?:"")}
 var category by remember{mutableStateOf(n?.category?:"عمومی")}
 var tags by remember{mutableStateOf(n?.tags?:"")}
 var checklist by remember{mutableStateOf(n?.checklist?:"")}
 var color by remember{mutableIntStateOf(n?.color?:0)}
 Scaffold(topBar={TopAppBar(
  title={Text(if(n==null)"یادداشت جدید" else "ویرایش یادداشت")},
  navigationIcon={IconButton(back){Icon(Icons.Default.ArrowBack,null)}},
  actions={TextButton({save(title,content,category,tags,checklist,color)}){Text("ذخیره")}}
 )}){p->
 Column(Modifier.fillMaxSize().padding(p).padding(16.dp).verticalScroll(rememberScrollState())){
  OutlinedTextField(title,{title=it},Modifier.fillMaxWidth(),label={Text("عنوان")},singleLine=true)
  Spacer(Modifier.height(10.dp))
  OutlinedTextField(content,{content=it},Modifier.fillMaxWidth().height(220.dp),label={Text("متن")})
  Spacer(Modifier.height(10.dp))
  OutlinedTextField(category,{category=it},Modifier.fillMaxWidth(),label={Text("دسته‌بندی")},singleLine=true)
  Spacer(Modifier.height(10.dp))
  OutlinedTextField(tags,{tags=it},Modifier.fillMaxWidth(),label={Text("برچسب‌ها")},singleLine=true)
  Spacer(Modifier.height(10.dp))
  OutlinedTextField(checklist,{checklist=it},Modifier.fillMaxWidth().height(140.dp),label={Text("چک‌لیست؛ هر مورد در یک خط")})
 }
 }
}

fun date(t:Long)=SimpleDateFormat("yyyy/MM/dd  HH:mm",Locale.getDefault()).format(Date(t))
