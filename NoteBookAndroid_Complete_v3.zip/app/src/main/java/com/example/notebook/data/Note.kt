package com.example.notebook.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="notes")
data class Note(
 @PrimaryKey(autoGenerate=true) val id:Long=0,
 val title:String="",
 val content:String="",
 val category:String="عمومی",
 val tags:String="",
 val checklist:String="",
 val color:Int=0,
 val createdAt:Long=System.currentTimeMillis(),
 val updatedAt:Long=System.currentTimeMillis(),
 val pinned:Boolean=false,
 val favorite:Boolean=false,
 val archived:Boolean=false,
 val deleted:Boolean=false
)
